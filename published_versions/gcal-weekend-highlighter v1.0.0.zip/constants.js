// ===== Config / styling =====
const WEEKEND_CLASS = "gcal-weekend";
const WEEKEND_STYLE_ID = "gcal-weekend-style";
const LIGHT_STYLE = `.${WEEKEND_CLASS}{background-color: rgba(200,200,200,1)!important}`;
const DARK_STYLE  = `.${WEEKEND_CLASS}{background-color: rgba(40,40,40,1)!important;}`;


