WeekendHighlighter.startWeekendHighlighter();
Themewatcher.watchGCalTheme(({ mode }) => Themewatcher.applyWeekendStyle(mode));
